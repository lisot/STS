package Clinica.Chao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChaoApplication.class, args);
	}
}
