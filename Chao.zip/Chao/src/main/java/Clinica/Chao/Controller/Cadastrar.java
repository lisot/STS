package Clinica.Chao.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import Clinica.Chao.Modelo.Paciente;
import Clinica.Chao.Repositorio.PacDB;

@Controller
@RequestMapping("/cadastro")
public class Cadastrar {
	@Autowired
	private PacDB BDClin;
	
	@GetMapping
	public ModelAndView Cadastrar(){
		ModelAndView RetornaTela = new ModelAndView("cadastrar");
		RetornaTela.addObject("PacientePost", new Paciente());
		return RetornaTela;
	}
	
	@PostMapping
	public ModelAndView CadastrarPost(Paciente PacientePost) {
		BDClin.save(PacientePost);
		ModelAndView RetornaTela = new ModelAndView("cadastrar");
		RetornaTela.addObject("PacientePost", new Paciente());
		return RetornaTela;
	}
}
