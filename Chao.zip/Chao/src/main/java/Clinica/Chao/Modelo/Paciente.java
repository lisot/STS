package Clinica.Chao.Modelo;
import java.io.Serializable; //Será auto increment

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity  //Diz que esta é uma classe de entidade que vai virar tabela
@Table(name="pac")
public class Paciente implements Serializable {
	private static final long serialVersionUID=1L; //terá o tamanho de 1 Long
	@Id  // Determina quem será a Primary Key
	@GeneratedValue(generator="increment") // Diz que será Auto increment no Banco H2 (em memória)
	@GenericGenerator(name="increment", strategy="increment") // Diz que será Auto increment no MySql
	private Long id;  
	private float Numpac; // Alt + Ins Getter and Setter
	@Column(name = "nome")
	private String Nome;
	private String Nasc, Endereco, Bairro, Cidade, Estado, Cep, Profissao, Fone, Medico, Trat, Cpf;
	private Boolean Pagameia;

	public Paciente() {  // Construtor vazio
	}

	public Paciente(float numpac, String nome, String nasc, String endereco, String bairro, String cidade,
			String estado, String cep, String profissao, String fone, String medico, String trat, String cpf,
			Boolean pagameia) { // Construtor sem ID
		Numpac = numpac;
		Nome = nome;
		Nasc = nasc;
		Endereco = endereco;
		Bairro = bairro;
		Cidade = cidade;
		Estado = estado;
		Cep = cep;
		Profissao = profissao;
		Fone = fone;
		Medico = medico;
		Trat = trat;
		Cpf = cpf;
		Pagameia = pagameia;
	}

	public Paciente(float numpac, String nome, String nasc, String endereco, String bairro, String cidade,
			String estado, String cep, String profissao, String fone, String medico, String trat, String cpf,
			Boolean pagameia, Long id) {  //Construtor com todos campos
		Numpac = numpac;
		Nome = nome;
		Nasc = nasc;
		Endereco = endereco;
		Bairro = bairro;
		Cidade = cidade;
		Estado = estado;
		Cep = cep;
		Profissao = profissao;
		Fone = fone;
		Medico = medico;
		Trat = trat;
		Cpf = cpf;
		Pagameia = pagameia;
		this.id = id;
	}

	public float getNumpac() { // Getter e Setter
		return Numpac;
	}

	public void setNumpac(float numpac) {
		Numpac = numpac;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getNasc() {
		return Nasc;
	}

	public void setNasc(String nasc) {
		Nasc = nasc;
	}

	public String getEndereco() {
		return Endereco;
	}

	public void setEndereco(String endereco) {
		Endereco = endereco;
	}

	public String getBairro() {
		return Bairro;
	}

	public void setBairro(String bairro) {
		Bairro = bairro;
	}

	public String getCidade() {
		return Cidade;
	}

	public void setCidade(String cidade) {
		Cidade = cidade;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

	public String getCep() {
		return Cep;
	}

	public void setCep(String cep) {
		Cep = cep;
	}

	public String getProfissao() {
		return Profissao;
	}

	public void setProfissao(String profissao) {
		Profissao = profissao;
	}

	public String getFone() {
		return Fone;
	}

	public void setFone(String fone) {
		Fone = fone;
	}

	public String getMedico() {
		return Medico;
	}

	public void setMedico(String medico) {
		Medico = medico;
	}

	public String getTrat() {
		return Trat;
	}

	public void setTrat(String trat) {
		Trat = trat;
	}

	public String getCpf() {
		return Cpf;
	}

	public void setCpf(String cpf) {
		Cpf = cpf;
	}

	public Boolean getPagameia() {
		return Pagameia;
	}

	public void setPagameia(Boolean pagameia) {
		Pagameia = pagameia;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
