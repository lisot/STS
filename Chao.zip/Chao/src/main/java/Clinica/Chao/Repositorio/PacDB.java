package Clinica.Chao.Repositorio;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import Clinica.Chao.Modelo.Paciente;

public interface PacDB extends CrudRepository<Paciente,Long> {
	public List<Paciente> findByNome(String nome);
}
