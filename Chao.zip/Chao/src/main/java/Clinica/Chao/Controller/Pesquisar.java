package Clinica.Chao.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import Clinica.Chao.Modelo.Paciente;
import Clinica.Chao.Modelo.PesquisaNome;
import Clinica.Chao.Repositorio.PacDB;

@Controller
@RequestMapping("/pesquisar")
public class Pesquisar {
	@Autowired   // instancia o BancoDados
	private PacDB BDClin;
	
	@GetMapping
	public ModelAndView Pesquisar(@ModelAttribute("pesquisanome") PesquisaNome pesquisanome){
		ModelAndView RetornaPesquisa = new ModelAndView("pesquisar");
		String resultado;
		if(pesquisanome.getNomeBuscar()==null){
			resultado = "%";
		}else{
			resultado = pesquisanome.getNomeBuscar();
		}
		List<Paciente> ListaPaciente = BDClin.findByNome(resultado);
		RetornaPesquisa.addObject("ListaPac", BDClin.findAll());
		return RetornaPesquisa;
	}
}
