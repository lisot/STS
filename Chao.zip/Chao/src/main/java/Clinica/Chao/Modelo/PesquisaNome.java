package Clinica.Chao.Modelo;

public class PesquisaNome {
	private String NomeBuscar;
	private String x;

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

	public String getNomeBuscar() {
		return NomeBuscar;
	}

	public void setNomeBuscar(String nomeBuscar) {
		NomeBuscar = nomeBuscar;
	}
	
}
