package Clinica.Chao.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TelaInicial {
	@GetMapping("/")
	public String TelaInicial(){
		return "telainicial";
	}
	
	@GetMapping("/pesar")
	public String Pesar(){
		return "pesar";
	}	
	
	@GetMapping("/saida")
	public String Saida(){
		return "filasaida";
	}	
	
	@GetMapping("/consultar")
	public String Consultar(){
		return "filaconsulta";
	}
}
